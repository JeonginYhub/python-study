filename=input("열 파일 이름을 입력하세요:")
infile=open(filename,'r')
count=0

for line in infile:
    count+=len(line)

infile.close()
print(f"파일 안에는 총{count}개의 글자가 있습니다.")