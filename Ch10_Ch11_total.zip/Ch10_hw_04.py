# 사용자로부터 파일 이름 입력 받기
filename = input("분석할 텍스트 파일 이름을 입력하세요 (예: data.txt): ")

# 빈도수를 저장할 딕셔너리 생성
char_count = {}


# 파일 열기
infile = open(filename, "r")

# 각 줄에 대해
for line in infile:
    # 각 문자에 대해
    for ch in line:
        if ch in char_count:
            char_count[ch] += 1
        else:
            char_count[ch] = 1

infile.close()
