infile=open("input.txt","r")
lines=infile.read()
print(lines)
infile.close()