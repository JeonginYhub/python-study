infile=open("input.txt","r")
lines=infile.readlines()
print(lines)
infile.close()