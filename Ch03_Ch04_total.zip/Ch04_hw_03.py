Drive=input("드라이브 이름:")
Directory=input("디렉토리 이름:")
File=input("파일 이름:")
Extension=input("확장자:")

print("완전한 이름은 %s:%s%s.%s"%(Drive,Directory,File,Extension))