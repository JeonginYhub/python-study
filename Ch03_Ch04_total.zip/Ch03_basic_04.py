x=int(input("첫 번째 수:"))
y=int(input("두 번째 수:"))
z=int(input("세 번째 수:"))
avg=(x+y+z)/3
print("평균=",avg)
