import time
G_time=time.time()

C_hour=G_time//60//60%24
K_minute=G_time//60%60
K_hour=C_hour+9
print("현재 한국 시간:",K_hour,"시",K_minute,"분")
