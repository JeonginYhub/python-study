import time
now=time.time()
thisYear=int(1970+(now//(365*24*3600)))


print("올해는 %s 입니다."%thisYear)
age=int(input("당신의 나이를 입력하세요:"))

age2050=age+2050-thisYear
print("2050년에는 %s살이군요."%age2050)


