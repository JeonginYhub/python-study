import turtle
t=turtle.Turtle()
t.shape("turtle")

t.setheading(45)
t.forward(141)
t.goto(0,0)
t.setheading(0)
t.forward(100)
t.setheading(90)
t.forward(100)
