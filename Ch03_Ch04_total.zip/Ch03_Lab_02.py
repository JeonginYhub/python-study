F=int(input("화씨온도: "))
C=(F-32)*5/9
print("섭씨온도:",C)
