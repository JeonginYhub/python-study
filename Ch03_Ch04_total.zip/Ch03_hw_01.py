chicken=int(input("닭의 수:"))
pig=int(input("돼지의 수:"))
cow=int(input("소의 수:"))
print("전체 다리의 수",chicken*2+pig*4+cow*4)
