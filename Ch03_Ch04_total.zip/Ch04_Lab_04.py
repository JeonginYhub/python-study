Ordinary=input("평문:")
Code=Ordinary[-1::-1]
print("암호문:",Code)
