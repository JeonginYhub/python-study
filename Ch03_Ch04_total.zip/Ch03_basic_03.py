x=1000
print("초깃값 x=",x)
x+=2;
print("x+=2 후의 x=",x)
x-=2;
print("x-=2 후의 x=",x)
