x=1
y=3
a=(-y)**3+2*x**2*y
print(a)
