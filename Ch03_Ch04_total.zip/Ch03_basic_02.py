sec=1000
min=sec//60
remainder=sec%60
print(min,"분",remainder,"초")
