import turtle
t=turtle.Turtle()
t.shape("turtle")


Name=turtle.textinput(None,"이름을 입력하시오:")
t.write("안녕하세요? %s씨, 터틀 인사드립니다"%Name)

t.left(90)
t.forward(100)
t.left(90)
t.forward(100)
t.left(90)
t.forward(100)
t.left(90)
t.forward(100)
