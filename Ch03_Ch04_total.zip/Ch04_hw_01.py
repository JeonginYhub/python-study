x=input("문자열을 입력하시오:")
print("%s하는 중"%x)
