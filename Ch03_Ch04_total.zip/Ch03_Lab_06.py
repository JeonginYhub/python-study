In=int(input("투입한 돈:"))
price=int(input("물건가격:"))
Out=In-price
Fivehundred=Out//500
Onehundred=(Out-(500*Fivehundred))//100
print("거스름돈:",Out)
print("500원 동전의 개수:",Fivehundred)
print("100원 동전의 개수:",Onehundred)
