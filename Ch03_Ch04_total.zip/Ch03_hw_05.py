import time
G_time=time.time() #그리니치 시간

C_hour=int(G_time//60//60%24) #현재 시각 (시)
C_minute=int(G_time//60%60) #현재 시각 (분)

print("현재 시간(영국 그리니치 시각):",C_hour,"시",C_minute,"분")
