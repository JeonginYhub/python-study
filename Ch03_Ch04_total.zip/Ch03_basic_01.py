p=int(input("나누어지는 수를 입력하시오: "))
q=int(input("나누는 수를 입력하시오 :"))
print("나눗셈의 몫=",p//q)
print("나눗셈의 나머지=",p%q)
