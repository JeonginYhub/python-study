Current_water_vapor=float(input("현재 수증기량을 입력하시오:"))
tem=int(input("기온을 입력하시오:"))

List=[[0,10,20,30],[4.8,9.4,17.3,30.4]]
index=tem//10

water_vapor=(Current_water_vapor/List[1][index])*100
print(water_vapor,"%")