import turtle
t=turtle.Turtle()
t.shape("turtle")
t.penup()
t.goto(-50,-10)
t.pendown()

screen = turtle.Screen()
screen.bgcolor("white")
screen.title("키보드로 터틀 움직이기")

obstacle = turtle.Turtle()
obstacle.shape("circle")
obstacle.color("red")
obstacle.goto(0,0)
obstacle.forward(200)
obstacle.right(90)
obstacle.forward(100)
obstacle.left(90)
obstacle.forward(100)
obstacle.penup()
obstacle.goto(-50,-50)
obstacle.pendown()
obstacle.forward(200)
obstacle.right(90)
obstacle.forward(100)
obstacle.left(90)
obstacle.forward(100)

def game_over():
    t.hideturtle()
    obstacle.hideturtle()
    t.write("충돌! 게임 오버!",align='center',)

def move_up():
    t.setheading(90)
    t.forward(5)

def move_down():
    t.setheading(270)
    t.forward(5)

def move_left():
    t.setheading(180)
    t.forward(5)

def move_right():
    t.setheading(0)
    t.forward(5)

screen.listen()
screen.onkey(move_up, "Up")  # 위 방향키
screen.onkey(move_down, "Down")  # 아래 방향키
screen.onkey(move_left, "Left")  # 왼쪽 방향키
screen.onkey(move_right, "Right")  # 오른쪽 방향키

def check_collision():
    # 첫 번째 사각형 (-100, 100)부터 (100, -100)까지 영역
    if -100 <= t.xcor() <= 100 and 0 <= t.ycor() <= 100:
        game_over()
    # 두 번째 사각형 (-150, 150)부터 (50, -150)까지 영역
    elif -150 <= t.xcor() <= 50 and -150 <= t.ycor() <= -50:
        game_over()

# 게임 루프
while True:
    screen.update()  # 화면 업데이트
    check_collision()  # 충돌 검사