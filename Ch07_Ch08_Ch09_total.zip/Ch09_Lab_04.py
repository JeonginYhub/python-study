awards={'이름':['팀 버너스리','리처드 해밍','에츠허르 데이크스트라','더글러스 엥겔바트','데니스 리치'],'수상년도':[2016,1968,1972,1997,1983]}

for award in awards:
    print(award['이름'])

for award in awards:
    if award['수상년도']<=1990:
        print(award['이름'],award['수상년도'])

nationality=set()
for award in awards:
    nationality.add(award['국적'])
print(nationality)