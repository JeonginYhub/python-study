num=[]

def testPrime():
    for n in range(2,101):
        is_prime=True
        for j in range(2,n):
            if n%j==0:
                is_prime=False
                break
        if is_prime:
            num.append(n)

testPrime()
print(num)