import turtle
t=turtle.Turtle()
t.speed(0)
t.width(3)
length = 10
colors = ["red", "orange", "yellow", "green", "blue", "purple"]

while length < 500:
    t.forward(length)
    t.pencolor(colors[length%6])
    t.right(89)
    length += 5