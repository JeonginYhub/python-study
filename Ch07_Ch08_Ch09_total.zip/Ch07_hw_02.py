List=[20,1,12,9,18]
for i in range(5):
    print("*"*List[i])