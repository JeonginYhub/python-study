colors=['red','blue','violet','yellow']

import turtle
t=turtle.Turtle()
t.shape("turtle")

def draw_square(x, y, c):
    t.penup()         # 선을 그리지 않게 펜을 올림
    t.goto(x, y)     # (x, y) 좌표로 이동
    t.pendown()       # 선을 그리도록 펜을 내림
    t.begin_fill()    # 색칠 시작
    t.fillcolor(c)    # 색상 설정
    for i in range(4):  # 사각형 그리기
        t.forward(50)  # 50만큼 앞으로 이동
        t.left(90)     # 90도 왼쪽으로 회전
    t.end_fill()      # 색칠 끝

# 사각형 그리기
x, y = -100, 100  # 시작 좌표
for c in colors:
    draw_square(x, y, c)
    x += 60  # x 좌표를 60씩 이동하여 사각형들을 옆으로 배치

turtle.done()