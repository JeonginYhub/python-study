import turtle

# 터틀 객체 생성
t = turtle.Turtle()

# 속도 설정
t.speed(3)

# 펜을 올리고 시작 위치를 설정 (중복 방지)
t.penup()
t.goto(-200, 100)
t.pendown()

# 사각형 그리기
def draw_square():
    for _ in range(4):
        t.forward(100)
        t.right(90)

# 삼각형 그리기
def draw_triangle():
    for _ in range(3):
        t.forward(100)
        t.left(120)

# 원 그리기
def draw_circle():
    t.circle(50)

# 별 그리기
def draw_star():
    for _ in range(5):
        t.forward(100)
        t.right(144)

# 도형들을 차례대로 그리기
def draw_shapes():
    # 사각형
    draw_square()
    
    # 위치 이동 후 삼각형
    t.penup()
    t.goto(150, 100)
    t.pendown()
    draw_triangle()
    
    # 위치 이동 후 원
    t.penup()
    t.goto(-150, -150)
    t.pendown()
    draw_circle()

    # 위치 이동 후 별
    t.penup()
    t.goto(150, -150)
    t.pendown()
    draw_star()

# 도형 그리기 함수 실행
draw_shapes()

# 터틀 창 유지
turtle.done()
