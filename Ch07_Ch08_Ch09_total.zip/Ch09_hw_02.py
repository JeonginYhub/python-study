dict={}
for i in range(1,11):
    dict[i]=i**2
print(dict)