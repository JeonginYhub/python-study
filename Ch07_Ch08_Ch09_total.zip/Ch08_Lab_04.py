import turtle
t=turtle.Turtle()
t.shape("turtle")    

def square(x, y):
    t.penup()
    t.goto(x, y)
    t.pendown()
    t.fillcolor("green")
    t.begin_fill()
    for i in range(4):
        t.forward(100)
        t.left(90)
    t.end_fill()
# 화면을 클릭할 때마다 click_handler 함수가 호출되도록 설정
turtle.onscreenclick(square)

turtle.done()