def add(a,b):
    return a+b
def subtract(a,b):
    return a-b
def multiply(a,b):
    return a*b
def division(a,b):
    if b==0:
        return "0으로 나눌 수 없습니다."
    else:
        return a/b

a=float(input("숫자1을 입력하시오:"))
b=float(input("숫자2를 입력하시오:"))

print(f"{a} + {b} = {add(a, b)}")
print(f"{a} - {b} = {subtract(a, b)}")
print(f"{a} * {b} = {multiply(a, b)}")
print(f"{a} / {b} = {division(a, b)}")