num=[100,96,209,22,30,117]

for i in num:
    if i%2==1:
        print(i,end=" ")