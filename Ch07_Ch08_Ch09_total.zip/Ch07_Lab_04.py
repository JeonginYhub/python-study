import turtle
t = turtle.Turtle()
t.shape("turtle")

# 색상 정의
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
color = [BLACK, BLUE, GREEN, RED, YELLOW]

turtle.colormode(255)

# 첫 번째 줄 (왼쪽부터 오른쪽: 파랑, 검정, 빨강)
t.penup()
t.goto(-100, 50)  # 첫 번째 원 위치
t.pendown()
t.color(color[1])  # BLUE
t.circle(50)


t.penup()
t.goto(0, 50)  # 두 번째 원 위치
t.pendown()
t.color(color[0])  # BLACK
t.circle(50)

t.penup()
t.goto(100, 50)  # 세 번째 원 위치
t.pendown()
t.color(color[3])  # RED
t.circle(50)

# 두 번째 줄 (왼쪽부터 오른쪽: 노랑, 초록)
t.penup()
t.goto(-50, -10)  # 네 번째 원 위치
t.pendown()
t.color(color[4])  # YELLOW
t.circle(50)

t.penup()
t.goto(50, -10)  # 다섯 번째 원 위치
t.pendown()
t.color(color[2])  # GREEN
t.circle(50)

# 종료
turtle.done()