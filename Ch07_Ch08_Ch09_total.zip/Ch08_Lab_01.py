def BMI(weight,height):
    return weight/(height*height)

height=float(input("키를 m단위로 입력하세요:"))
weight=float(input("몸무게를 kg단위로 입력하세요:"))
BMI_value=BMI(weight,height)

if BMI_value<18.5:
    print("당신은 저체중입니다.")
elif BMI_value>=18.5 and BMI_value<=22.9:
    print("당신은 정상입니다.")
elif BMI_value>=23 and BMI_value<=24.9:
    print("당신은 과체중입니다.")
elif BMI_value>=25 and BMI_value<=29.9:
    print("당신은 경도비만입니다.")
else:
    print("당신은 고도비만입니다.")