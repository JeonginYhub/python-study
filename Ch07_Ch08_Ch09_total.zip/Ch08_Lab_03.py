import turtle
t=turtle.Turtle()
t.shape("turtle")

def n_polygon():
    num=int(input("n각형의 n값을 입력하시오:"))
    for i in range(num):
        180*234
        t.forward(100)
        t.left(180-(180*(num-2)/num))

n_polygon()