exchangerate={'미국':1182.5,'일본':1078.14,'유럽연합':1286.74,'중국':169.22}
unit={'미국':"달러",'일본':'엔','유럽연합':'유로','중국':'위안'}

money=float(input("환전 금액(원)을 입력하세요:"))
country=input("국가를 입력하세요:")

def ex(money,country):
    if country in exchangerate:
        return money/exchangerate[country]
    else:
        return None

exmoney=ex(money,country)

if exmoney is not None:
    print(f"{money}원은 {exmoney:.2f}{unit[country]}입니다.")
else:
    print("해당 국가 정보가 없습니다.")