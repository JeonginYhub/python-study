import random
List=[]
for i in range(10):
    List.append(random.randint(1,100))
print(List)