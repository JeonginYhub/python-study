import random
colors=["green","blue","yellow","white","skyblue"]

import turtle
t=turtle.Turtle()
t.shape("turtle")

s = turtle.Screen()
s.bgcolor("black")

def draw_star(colors, length, x, y):
    t.penup()         # 선을 그리지 않게 펜을 올림
    t.goto(x, y)     # (x, y) 좌표로 이동
    t.pendown()
    t.fillcolor(random.choice(colors))       
    t.begin_fill()    # 색칠 시작  
    for j in range(5):
        t.forward(length)
        t.right(144)
        t.forward(length)
        t.left(72)    
    t.end_fill()

for i in range(10):
    length = random.randint(30, 150)
    x = random.randint(-150, 150)
    y = random.randint(-150, 150)

    draw_star(colors, length, x, y)

turtle.done()