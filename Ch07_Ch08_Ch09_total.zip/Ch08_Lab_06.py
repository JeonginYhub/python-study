import turtle

# 터틀 객체 생성
t = turtle.Turtle()
t.shape("turtle")

# x축, y축 그리기
def draw_axes():
    t.penup()
    t.goto(0, 0)  # x축 그리기 시작 위치
    t.pendown()
    t.forward(200)  # x축 그리기
    t.penup()
    t.goto(0, 0)  # y축 그리기 시작 위치
    t.setheading(90)  # y축 방향으로 회전
    t.pendown()
    t.forward(200)  # y축 그리기
    t.penup()

# f(x) = x^2 + 1 함수 정의
def f(x):
    return x**2 + 1

# f(x)를 그리기 위한 함수
def draw_function():
    t.penup()
    for x in range(0, 151, 1):  # x 값을 0부터 150까지 1씩 증가
        y = f(x)  # 함수 f(x) 계산
        y = y * 0.01  # y 값을 화면 크기에 맞게 조정
        t.goto(x, y)  # 화면의 중심을 맞추기 위해 이동
        t.pendown()  # 선을 그리기 시작
    t.penup()  # 그리기 종료

# x축, y축 그리기
draw_axes()

# f(x) 그리기
draw_function()

# 터틀 그래픽 종료
turtle.done()