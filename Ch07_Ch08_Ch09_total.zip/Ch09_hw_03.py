d={"Apple":1,"Banana":2,"Grape":3}
for k,v in d.items():
    print('{}'"->"'{}'.format(k,v))