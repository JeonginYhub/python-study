import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# 이메일 정보
sender_email = "----"  # 보낼 이메일 주소
receiver_email = "----"  # 받을 이메일 주소
password = "----"  # 앱 비밀번호 (2단계 인증 설정 후 생성한 앱 비밀번호)

# 이메일 제목과 본문
subject = "테스트 이메일"
body = "이것은 파이썬을 이용한 이메일 전송 테스트입니다."

# MIME 객체 생성 (멀티파트 메시지 형식으로)
message = MIMEMultipart()
message["From"] = sender_email
message["To"] = receiver_email
message["Subject"] = subject

# 본문 내용 첨부
message.attach(MIMEText(body, "plain"))

# SMTP 서버 연결
try:
    # SMTP 서버 연결 (Gmail의 경우)
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()  # TLS (보안 연결) 활성화
    server.login(sender_email, password)  # 로그인
    server.sendmail(sender_email, receiver_email, message.as_string())  # 이메일 전송
    print("이메일이 성공적으로 전송되었습니다.")
except Exception as e:
    print(f"이메일 전송 실패: {e}")
finally:
    server.quit()  # 서버 연결 종료
