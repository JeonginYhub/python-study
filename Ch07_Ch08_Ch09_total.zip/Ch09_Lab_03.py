beans={'rR':24,'RR':28,'Rr':24,'rr':24}
B=beans['rR']+beans['RR']+beans['Rr']
b=beans['rr']

print(beans,B/b,": 1")