List=[80,20,20,30,60,30]
s=set(List)
for a in sorted(s):
    print(a)