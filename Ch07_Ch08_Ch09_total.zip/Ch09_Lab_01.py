import random
you=input("가위, 바위, 보 입력:")
rockscissorspaper=["가위","바위","보"]
rsp=random.choice(rockscissorspaper)
if rsp==you:
    print("비겼습니다.")
elif (rsp=="가위" and you=="바위") or (rsp=="바위" and you=="보") or (rsp=="보" and you=="가위"):
    print("이겼습니다.")
else:
    print("졌습니다.")