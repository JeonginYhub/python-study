print(7*24)
