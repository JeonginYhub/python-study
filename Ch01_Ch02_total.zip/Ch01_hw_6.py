import turtle
t=turtle.Turtle()
t.shape("square")
t.forward(100)
