import turtle
t=turtle.Turtle()
t.shape("turtle")
t.circle(100)
