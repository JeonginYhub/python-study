import turtle
t=turtle.Turtle()
t.shape("turtle")

t.down()
t.goto(100,0)
t.up()
t.goto(0,200)
t.down()
t.goto(100,200)
