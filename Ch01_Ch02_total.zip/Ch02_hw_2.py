x=int(input("반지름을 입력하세요: "))
print("반지름이",str(x),"인 원의 넓이 =",x*x*3.14)
