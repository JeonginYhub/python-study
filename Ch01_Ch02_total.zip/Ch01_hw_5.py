import turtle
t=turtle.Turtle()
t.shape("turtle")
t.color("blue")
t.forward(100)
