x=int(input("넓이를 구하고자 하는 원의 반지름: "))
width=x*x*3.14
print(width)
