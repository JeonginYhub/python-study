import turtle
t=turtle.Turtle()
t.shape("turtle")
side=200

t.forward(side)
t.left(120)
t.forward(side)
t.left(120)
t.forward(side)
t.left(120)
