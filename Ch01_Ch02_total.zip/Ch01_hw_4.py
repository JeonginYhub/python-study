import turtle
t=turtle.Turtle()
t.shape("turtle")
t.width(10)
t.forward(100)
t.left(90)
t.forward(100)
