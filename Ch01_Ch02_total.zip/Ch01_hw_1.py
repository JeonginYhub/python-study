print("반갑습니다. 파이썬!")
print(2*3/10)
print("Hello", "World", "!!!") 
