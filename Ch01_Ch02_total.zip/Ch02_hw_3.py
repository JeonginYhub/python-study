import turtle
t=turtle.Turtle()
t.shape("turtle")
side=100

t.forward(side)
t.left(120)
t.forward(side)
t.left(120)
t.forward(side)
t.left(120)
