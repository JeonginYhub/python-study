attempts=0
answer=10

print("1부터 100 사이의 숫자를 맞추시오")
while True:
    num=int(input("숫자를 입력하시오:"))
    attempts+=1
    if num<answer:
        print("낮음!")
    elif num>answer:
        print("높음!")
    else:
        print("축하합니다. 시도횟수=",attempts)
        break