age=int(input("나이를 입력하시오:"))

if age>=15:
    print("영화를 관람할 수 있습니다.")
else:
    print("영화를 관람할 수 없습니다.")
