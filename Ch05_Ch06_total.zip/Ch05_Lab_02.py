import turtle
t=turtle.Turtle()
t.shape("turtle")

t.penup()
t.goto(100,100)
t.pendown()
t.write("입력된 정수는 양의 정수입니다.")

t.penup()
t.goto(100,0)
t.pendown()
t.write("입력된 정수는 0입니다.")

t.penup()
t.goto(100,-100)
t.pendown()
t.write("입력된 정수는 음음의 정수입니다.")

t.penup()
t.goto(0,0)
t.pendown()

Num=int(turtle.textinput(None,"숫자를 입력하시오:"))


if Num>0:
    t.goto(100,100)
elif Num==0:    
    t.goto(100,0)
else:
    t.goto(100,-100)


