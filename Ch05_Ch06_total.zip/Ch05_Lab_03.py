print("주민등록번호의 성별 정보 번호를 생성합니다.")
num=int(input("생성번호:"))
if num%2!=0:
    print('남성입니다.')
else:
    print("여성입니다.")
print("프로그램을 종료합니다.")