import turtle
t=turtle.Turtle()
t.shape("turtle")

t.goto(0,0)
for i in range(6):
    t.setheading(30+(i-1)*60)
    t.forward(100); t.forward(-30); t.left(60); t.forward(30); t.forward(-30); t.right(120); t.forward(30); t.forward(-30);t.left(60)
    t.goto(0,0)
    
