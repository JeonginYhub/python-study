centerx1=int(input("큰 원의 중심좌표 x1:"))
centery1=int(input("큰 원의 중심좌표 y1:"))
radius1=int(input("큰 원의 반지름:"))
centerx2=int(input("작은 원의 중심좌표 x2:"))
centery2=int(input("작은 원의 중심좌표 y2:"))
radius2=int(input("작은 원의 반지름:"))

import turtle
t=turtle.Turtle()
t.shape("turtle")
tt=turtle.Turtle()
tt.shape("classic")

t.penup()
t.goto(centerx1,centery1-radius1)
t.pendown()
t.circle(radius1)
t.penup()
t.goto(centerx2,centery2-radius2)
t.pendown()
t.circle(radius2)

dist=((centerx1-centerx2)**2+(centery1-centery2)**2)**(1/2)

t.penup()
t.goto(centerx2,centery2)
t.pendown()

if dist==0:
    t.write("동심원")
elif dist==radius1-radius2:
    t.write("내접")
elif radius1-radius2<dist<radius1+radius2:
    t.write("두 점에서 만납니다.")
elif dist>radius1+radius2:
    t.write("만나지 않고 외부에 있습니다.")
elif dist==radius1+radius2:
    t.write("외접")
elif dist<radius1-radius2:   
    t.write("만나지 않고 내부에 있습니다.")
