for i in range(1,6,1):
    print(i,end=" ")