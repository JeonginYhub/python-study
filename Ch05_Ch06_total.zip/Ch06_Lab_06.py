import turtle
import random
t=turtle.Turtle()
t.shape("turtle")

turtle.colormode(255)

for i in range(30):
    x=random.randint(-300,300)
    y=random.randint(-300,300)
    t.penup()
    t.goto(x,y)
    t.pendown()
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    t.fillcolor(r,g,b)
    length=random.randint(10,300)

    t.begin_fill()
    for j in range(4):
        t.forward(length)
        t.right(90)
    t.end_fill()
