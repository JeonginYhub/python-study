country=input("국가를 입력하시오:")
if country=="한국" or country=="대한민국":
    island=input("도를 입력하시오:")
    if island=="제주" or island =="제주도":
        print("배송료는 10000원입니다.")
    else:
        print("배송료는 5000원입니다.")
else:
    print("배송료는 20000원입니다.")

    