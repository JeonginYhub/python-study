import random
answer=random.randint(1,3)
score=0

while True:
    you=int(input("범인이 숨은 방을 고르시오."))
    if answer!=you:
        score-=10
        print("오답!")
    else:
        score+=100
        print("정답! 점수는",score)
        break
    