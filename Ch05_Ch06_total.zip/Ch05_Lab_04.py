import turtle
import random

# 터틀 객체 생성
t=turtle.Turtle()

# 화면 객체 생성
screen=turtle.Screen()

# 두 개의 이미지 파일 설정
image1="front.gif"
image2="back.gif"

# 두 이미지를 화면에 등록
screen.addshape(image1)
screen.addshape(image2)

# 초기 터틀의 모양을 'front.gif'로 설정
t.shape(image1)

# 랜덤으로 0 또는 1을 선택
coin=random.randint(0,1)

# 랜덤한 값에 따라 동작
if coin==0:
    t.shape(image1)
    t.stamp()     # coin이 0이면 'front.gif' 모양을 사용하고, 스탬프 찍기
else:
    t.shape(image2)
    t.stamp()     # coin이 1이면 'back.gif' 모양을 사용하고, 스탬프 찍기
