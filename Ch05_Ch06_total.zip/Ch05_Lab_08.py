import turtle
t=turtle.Turtle()
t.shape("turtle")

shape=turtle.textinput(None,"도형을 입력하시오:")

if shape == "직사각형":
    r_width=turtle.textinput(None,"가로:")
    r_height=turtle.textinput(None,"세로:")
    if r_width!=r_height:
        t.forward(int(r_width))
        t.left(90)
        t.forward(int(r_height))
        t.left(90)
        t.forward(int(r_width))
        t.left(90)
        t.forward(int(r_height))
    else:
        print("직사각형이 아닌 정사각형입니다.")
elif shape == "정삼각형":
    t_side=turtle.textinput(None,"한 변의 길이:")
    t.forward(int(t_side))
    t.left(120)
    t.forward(int(t_side))
    t.left(120)
    t.forward(int(t_side))
elif shape == "원":
    c_radius= turtle.textinput(None,"반지름의 길이:")
    t.circle(int(c_radius))
