a=int(input("a:"))
b=int(input("b:"))
c=int(input("c:"))
print("2차 함수: (%s*x^2)+%s*x+%s"%(a,b,c))

x=b**2-4*a*c


if b**2-4*a*c>0:
    print("2개의 실근이 있습니다:",((-b+x**(0.5))/(2*a)),"와",((-b-x**(0.5))/(2*a)))
elif b**2-4*a*c==0:
    print("1개의 실근이 있습니다:",((-b+x**(0.5))/(2*a)))
else:
    print("실근이 존재하지 않습니다.")

