import turtle
t=turtle.Turtle()
t.shape("turtle")
import random

step_length = [10, 20, 30]
angles = [0, 45, 90, 135, 180, 225, 270, 315]
    

for i in range(200):
    t.forward(random.choice(step_length))
    t.setheading(random.choice(angles))