import turtle
t=turtle.Turtle()
t.shape("turtle")

shape=int(turtle.textinput(None,"몇각형을 원하시나요?:"))

for i in range(shape):
    t.forward(100)
    t.left(360/shape)