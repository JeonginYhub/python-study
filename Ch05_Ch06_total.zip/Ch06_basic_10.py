sign=True

while sign:
    light=input("신호등 색상을 입력하시오:")
    if light=='blue':
        sign=False

print("전진!!")