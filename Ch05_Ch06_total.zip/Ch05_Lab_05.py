num1=input("1번 전지가 있습니까? (Y/N)")
num2=input("2번 전지가 있습니까? (Y/N)")
if (num1 == "y" or num1 == "Y")and(num2== "y" or num2 == "Y"):
    print("직렬연결 : 전구에 불이 켜집니다.")
    print("병렬연결 : 전구에 불이 켜집니다.")
elif (num1 == "n" or num1 == "N") and(num2 == "n" or num2 == "N"):
    print("직렬연결 : 전구에 불이 꺼집니다.")
    print("병렬연결 : 전구에 불이 꺼집니다.")
else:
    print("직렬연결 : 전구에 불이 꺼집니다.")
    print("병렬연결 : 전구에 불이 켜집니다.")