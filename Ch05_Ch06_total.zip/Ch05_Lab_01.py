len_a=int(input("변a의 길이:"))
len_b=int(input("변b의 길이:"))
len_c=int(input("변c의 길이:"))

if len_c>=len_a+len_b:
    print("단, c<a+b입니다.")
else:
    if len_c**2==len_a**2+len_b**2:
        print("직각삼각형입니다.")
    else:
        print("직각삼각형이 아닙니다.")