import turtle
t=turtle.Turtle()
t.shape("turtle")
import math

for i in range(360):
    S=math.sin(math.pi*i/180)
    #radian=math.pi(3.14)*각도(i)/180
    t.goto(i,S*100) #y좌표의 s값에 따라 높낮이 폭 변화
turtle.done()
