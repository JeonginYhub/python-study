for i in range(5):
    print("방문을 환영합니다!")