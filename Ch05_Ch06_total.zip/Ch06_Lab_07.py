num=int(input("자연수 입력:"))

for i in range(1,num+1):
    if num%i==0:
        print(i)
    