import random
r1=random.randint(1,6)
r2=random.randint(1,6)

print("첫번째 주사위=",r1,"두번째 주사위=",r2)