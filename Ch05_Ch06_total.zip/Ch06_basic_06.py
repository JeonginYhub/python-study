count=1
sum=0
while count<=100:
    sum+=count
    count=count+1
print("1부터 100가지의 합은",sum,"입니다.")