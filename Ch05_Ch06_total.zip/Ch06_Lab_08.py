a=int(input("정수1 입력:"))
b=int(input("정수2 입력:"))

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

print("두 수의 최대공약수:",gcd(a,b))

