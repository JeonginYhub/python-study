print("A-B")
for i in range(2):
    print("C-D")