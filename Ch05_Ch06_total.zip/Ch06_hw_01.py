answer=input("3*9는")
while 3*9 != answer:
    answer=int(input("3*9는"))
print("맞았습니다.")