import turtle
t=turtle.Turtle()
for i in range(5):
    t.circle(100)
    t.left(60)
t.circle(100)